# STOCK AI — iPhone PWA

Prototype éducatif de terminal boursier, optimisé pour iPhone.

## Contenu
- Tableau de bord responsive, marchés mondiaux et liste de surveillance.
- Indicateurs RSI et lecture de tendance illustratifs.
- Signaux techniques pédagogiques (pas de recommandations d'achat).
- Portefeuille virtuel local, sans transaction réelle.
- Mode démo avec valeurs fictives.
- Option d'intégration Twelve Data (clé API personnelle, cotations selon plan/quota).

## Publier pour iPhone
Une PWA doit être servie en HTTPS. Le plus simple :
1. Créer un dépôt GitHub nommé `stock-ai`.
2. Envoyer tous les fichiers de ce dossier à la racine du dépôt.
3. Dans GitHub : Settings → Pages → Deploy from a branch → `main` / `root`.
4. Ouvrir l'URL GitHub Pages dans Safari sur l'iPhone.
5. Bouton Partager → Sur l’écran d’accueil → Ajouter.

## Données réelles
Ouvrir ⚙ Paramètres, choisir API Twelve Data et saisir une clé obtenue auprès du fournisseur. La version prototype appelle le point `/quote` pour les symboles de la liste. Les marchés et symboles disponibles, délais, quotas et conditions dépendent du fournisseur et de l'abonnement.
**Sécurité :** cette version conserve la clé dans le stockage local du navigateur et appelle l'API depuis l'iPhone. Ne publie pas une clé dans un dépôt public. Pour un déploiement public multi-utilisateur, créer un backend sécurisé qui conserve la clé côté serveur.

## Important
- Les valeurs en mode démo sont fictives.
- Les signaux techniques sont des heuristiques explicables, non des prévisions.
- Aucun système ne peut déterminer précisément ni garantir le meilleur moment pour acheter une action.
- Ce prototype n'envoie aucun ordre de bourse et ne remplace pas un professionnel qualifié.
